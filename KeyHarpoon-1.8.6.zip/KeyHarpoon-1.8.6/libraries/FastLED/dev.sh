#!/bin/bash

uv run dev/dev.py